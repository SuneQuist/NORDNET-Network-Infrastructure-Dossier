import unittest
import importlib.util
from pathlib import Path
from unittest import mock
import sys

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
# Helpers are in the installed lab when deployed; for offline tests these are
# provided by the test runner through copied lab fixtures or stubs.

class AuditTests(unittest.TestCase):
    def test_offline_helpers(self):
        # Only import if host NORDNET dependencies are installed locally.
        try:
            import nordnet_enterprise_audit as a
        except ImportError:
            self.skipTest('NORDNET dependencies not in this standalone tests folder')
        a0='show running-config\nversion 15.9\nhostname CE-UNIV\nrouter bgp 65210\nend\n'
        b0='show startup-config\nUsing 3344 bytes\nversion 15.9\nhostname CE-UNIV\nrouter bgp 65210\nend\n'
        self.assertEqual(a.check_ios(a0,b0,['hostname CE-UNIV'])['status'],'PASS')
        self.assertEqual(a.check_ios(a0,b0,['missing line'])['status'],'FAIL')
        b1='show startup-config\nversion 15.9\nhostname CE-UNIV\nend\n'
        self.assertEqual(a.check_ios(a0,b1,['hostname CE-UNIV'])['status'],'WARN')
    def test_dhcp_parser(self):
        try:
            import nordnet_enterprise_audit as a
        except ImportError:
            self.skipTest('NORDNET dependencies not in this standalone tests folder')
        out='NAME : PC-HQ-DHCP\nIP/MASK : 10.10.10.101/24\nGATEWAY : 10.10.10.1\nDNS : 10.10.30.250'
        self.assertEqual(a.check_dhcp_vpcs(out,'10.10.10.0/24','10.10.10.1')['status'],'PASS')
        self.assertEqual(a.check_dhcp_vpcs(out,'10.11.10.0/24','10.11.10.1')['status'],'FAIL')
        self.assertEqual(a.check_dhcp_vpcs('GATEWAY : 10.10.10.1','10.10.10.0/24','10.10.10.1')['status'],'FAIL')

    def test_expanded_topology_and_missing_link(self):
        try:
            import nordnet_enterprise_audit as a
            import nordnet_local as local
            import nordnet_enterprise as enterprise
            import yaml
        except ImportError:
            self.skipTest('NORDNET dependencies not in this standalone tests folder')
        inv=yaml.safe_load((Path(local.__file__).parent/'inventory.yaml').read_text())
        links=local.desired_links(inv)+list(enterprise.LINKS)
        nodes={}
        def port_record(node, iface):
            if isinstance(iface,int):
                adapter,number,name=iface,0,'eth'+str(iface)
            elif iface.startswith('GigabitEthernet'):
                adapter,number=map(int,iface.removeprefix('GigabitEthernet').split('/'))
                name=f'Gi{adapter}/{number}'
            else:
                adapter,number,name=0,0,iface
            ports=nodes.setdefault(node,{'name':node,'node_id':node,'ports':[],
                             'node_type':'docker' if node==enterprise.SERVICE else 'qemu',
                             'compute_id':'vm','properties':{'image':enterprise.IMAGE}})['ports']
            result={'node_id':node,'adapter_number':adapter,'port_number':number}
            if not any(x['adapter_number']==adapter and x['port_number']==number for x in ports):
                ports.append({'name':name,'adapter_number':adapter,'port_number':number})
            return result
        api_links=[]
        for src,si,dst,di in links:
            api_links.append({'nodes':[port_record(src,si),port_record(dst,di)]})
        class MockAPI:
            def __init__(self, ls):self.ls=ls
            def call(self, method,path):return self.ls
        ok=a.topology_report(MockAPI(api_links),'/v2/projects/simulation',nodes,inv)
        self.assertEqual(ok['status'],'PASS')
        self.assertEqual(ok['links_checked'],len(links))
        bad=a.topology_report(MockAPI(api_links[:-1]),'/v2/projects/simulation',nodes,inv)
        self.assertEqual(bad['status'],'FAIL')
        self.assertTrue(any('PC-BR-DHCP' in x for x in bad['missing_or_invalid_links']))

if __name__=='__main__': unittest.main()
