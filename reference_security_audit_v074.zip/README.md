# NORDNET v0.7.4 — Read-only persistence audit

## Why this exists

The older `nordnet_recover.py --audit` requires the **exact** v0.6.1 node/link set and therefore refuses the legitimate v0.7 Docker services node and two DHCP clients. **Do not bypass the older repair guard**: its repair mode was never built for v0.7.

This update is a separate, **read-only** audit with no repair option. It uses existing `nordnet_local.py`, `nordnet_enterprise.py`, `nordnet_recover.py`, `ios_console.py`, and `inventory.yaml` helpers. It does not restart nodes, execute `copy run start`, configure routers, alter links, or save VPCS.

## Install

Copy `nordnet_enterprise_audit.py` into `C:\Users\<you>\Downloads\nordnet_local_bulk\`, next to your existing automation files. Do not overwrite existing files. The package's tests are optional.

## Run

From PowerShell:

```powershell
cd "$env:USERPROFILE\Downloads\nordnet_local_bulk"
py -3.12 .\nordnet_enterprise_audit.py --project-id 381c9ab5-1701-4481-a808-6d13439ddeed
```

This checks: current project UUID; the original v0.6.1 links and five new enterprise links; the service node type/image; ten IOS devices' running/startup configuration markers and normalized configuration comparison; seven static VPCS addresses and both DHCP clients' current addresses/gateways.

It stores a summary (markers, SHA-256 hashes and status; **not entire configurations**) in `evidence/enterprise_audit/`.

## How to interpret

- `PASS`: all selected running/startup markers present, normalized configs match, endpoint running addresses match, and topology matches the expected v0.7 links. This is not a reboot test.
- `WARN`: a running/startup difference exists although selected required markers exist. Review differences manually before deciding whether to save.
- `FAIL`: required markers/addresses/links are missing or configuration could not be reliably parsed.
- `ATTENTION`: one or more checks are not PASS; no repair is performed.

**Limitations:** This is an offline-tested utility, not yet tested with your live GNS3 VM. It can't certify that VPCS startup scripts or Docker startup behavior survive a reboot. Run `py -3.12 .\nordnet_enterprise.py --verify` separately to validate operational services. When scheduling a cold-start validation, first export the working project and ensure the services node has its own startup configuration persistence plan.
